import json
import time
from datetime import datetime
from datetime import timedelta

import pandas as pd
import paho.mqtt.client as mqtt


# Lokasi dataset
DATASET_PATH = "../Crop_recommendation.csv"

# Membaca dataset
df = pd.read_csv(DATASET_PATH)

# Ambil 365 data pertama
df = df.head(30)

# MQTT Client
client = mqtt.Client()

client.connect(
    "localhost",
    1883
)

print("Simulator berjalan...")
print(f"Jumlah data: {len(df)}")

start_date = datetime(
    2026,
    1,
    1
)



for index, row in df.iterrows():

    simulation_date = (
        start_date +
        timedelta(days=index)
    ).strftime("%Y-%m-%d")

    payload = {
        

        "nitrogen": float(row["N"]),
        "phosphorus": float(row["P"]),
        "potassium": float(row["K"]),

        "temperature": float(row["temperature"]),
        "humidity": float(row["humidity"]),

        "ph": float(row["ph"]),
        "rainfall": float(row["rainfall"]),
        "simulation_date": simulation_date
    }

    client.publish(
        "durian/monitoring",
        json.dumps(payload)
    )

    print(
        f"Data ke-{index+1} terkirim"
    )

    time.sleep(1)