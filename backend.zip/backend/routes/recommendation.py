from fastapi import APIRouter
from database.session import SessionLocal
from models.rekomendasi import Rekomendasi

from services.recommendation_service import (
    generate_recommendation
)

router = APIRouter()


@router.post("/generate")
def generate(payload: dict):

    return generate_recommendation(

        monitoring_id=
            payload["monitoring_id"],

        varietas_id=
            payload["varietas_id"],

        fase_id=
            payload["fase_id"]
    )

@router.get("/latest")
def latest_recommendation():

    db = SessionLocal()

    data = (
        db.query(Rekomendasi)
        .order_by(
            Rekomendasi.id.desc()
        )
        .first()
    )

    db.close()

    return data

@router.get("/history")
def recommendation_history():

    db = SessionLocal()

    data = (
        db.query(Rekomendasi)
        .order_by(
            Rekomendasi.id.desc()
        )
        .all()
    )

    result = []

    for row in data:

        result.append({

            "id": row.id,

            "monitoring_id":
                row.monitoring_id,

            "varietas_id":
                row.varietas_id,

            "fase_id":
                row.fase_id,

            "jenis_pupuk":
                row.jenis_pupuk,

            "dosis":
                row.dosis,

            "kategori":
                row.kategori,

            "created_at":
                row.created_at
        })

    db.close()

    return result   