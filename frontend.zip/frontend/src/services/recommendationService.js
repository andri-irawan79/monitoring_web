import axios from "axios";

const API_URL = "http://127.0.0.1:8000";

export const getLatestRecommendation = async () => {
  const response = await axios.get(
    `${API_URL}/recommendation/latest`
  );

  return response.data;
};

export const getRecommendationHistory = async () => {
  const response = await axios.get(
    `${API_URL}/recommendation/history`
  );

  return response.data;
};

export const generateRecommendation = async (
  monitoringId,
  varietasId,
  faseId
) => {

  const response = await axios.post(
    `${API_URL}/recommendation/generate`,
    {
      monitoring_id: monitoringId,
      varietas_id: varietasId,
      fase_id: faseId
    }
  );

  return response.data;
};
