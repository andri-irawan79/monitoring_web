<template>
  <div
    class="
      bg-white
      rounded-3xl
      border border-slate-100
      shadow-sm
      hover:shadow-lg
      transition-all
      duration-300
      p-6
    "
  >
    <slot />
  </div>
</template>
