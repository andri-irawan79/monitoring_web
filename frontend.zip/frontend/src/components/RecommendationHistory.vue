<template>

<div>

  <h2>Riwayat Rekomendasi</h2>

  <table>

    <thead>

      <tr>

        <th>ID</th>
        <th>Pupuk</th>
        <th>Dosis</th>
        <th>Kategori</th>

      </tr>

    </thead>

    <tbody>

      <tr
        v-for="item in recommendations"
        :key="item.id"
      >

        <td>{{ item.id }}</td>
        <td>{{ item.jenis_pupuk }}</td>
        <td>{{ item.dosis }}</td>
        <td>{{ item.kategori }}</td>

      </tr>

    </tbody>

  </table>

</div>

</template>

<script setup>

defineProps({
  recommendations: Array
})

</script>
