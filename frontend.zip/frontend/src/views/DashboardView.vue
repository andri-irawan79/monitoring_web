<script setup>
import { ref, onMounted } from "vue";

import { getLatestMonitoring, getMonitoringHistory } from "../services/monitoringService";

// import DashboardHeader from "../components/dashboard/DashboardHeader.vue";
import DashboardStatGrid from "../components/dashboard/DashboardStatGrid.vue";
import MonitoringChartCard from "../components/dashboard/MonitoringChartCard.vue";
import NutrientStatusCard from "../components/dashboard/NutrientStatusCard.vue";
import MonitoringTableCard from "../components/dashboard/MonitoringTableCard.vue";
import DashboardSummaryCard from "../components/dashboard/DashboardSummaryCard.vue";
import DashboardHero from "../components/dashboard/DashboardHero.vue";
import MonitoringInsight from "../components/dashboard/MonitoringInsight.vue";
import { getDashboardSummary } from "../services/dashboardService";

const monitoring = ref(null);
const history = ref([]);
const summary = ref({});

onMounted(async () => {
  monitoring.value = await getLatestMonitoring();
  history.value = await getMonitoringHistory();
  summary.value = await getDashboardSummary();
});
</script>

<template>
<div>

    <!-- <DashboardHeader /> -->
    <DashboardHero
        :summary="summary"
    />
    <DashboardSummaryCard
        :summary="summary"
    />

    <DashboardStatGrid
        v-if="monitoring"
        :monitoring="monitoring"
    />

    <div
        class="
            grid
            grid-cols-1
            xl:grid-cols-3
            gap-6
            mt-8
        "
    >

        <div class="xl:col-span-2">

            <MonitoringChartCard
                :data="history"
            />

            <MonitoringInsight
                v-if="monitoring"
                :monitoring="monitoring"
                :summary="summary"
            />

        </div>



        <div>

            <NutrientStatusCard
                v-if="monitoring"
                :monitoring="monitoring"
            />

        </div>

    </div>

    <div class="mt-8">

        <MonitoringTableCard
            :data="history"
        />

    </div>

</div>
</template>
